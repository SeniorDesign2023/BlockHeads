package com.example.credhub.ui.signup;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.credhub.R;
import com.example.credhub.MainActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class signup extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, emailEditText, phoneNumberEditText, birthdateEditText, passwordEditText, repasswordEditText, pinEditText, repinEditText;
    private CheckBox agreeCheckBox;
    private Button signupButton, chooseImageButton;
    private ImageButton backButton;
    private FirebaseAuth mAuth;
    private DatabaseReference rootDatabaseRef;
    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initializeViews();
        mAuth = FirebaseAuth.getInstance();
        rootDatabaseRef = FirebaseDatabase.getInstance().getReference();

        backButton.setOnClickListener(v -> finish());

        signupButton.setOnClickListener(v -> signUp());

        chooseImageButton.setOnClickListener(v -> chooseImage());
    }

    private void initializeViews() {
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        repasswordEditText = findViewById(R.id.repasswordEditText);
        pinEditText = findViewById(R.id.pinEditText);
        repinEditText = findViewById(R.id.repinEditText);
        agreeCheckBox = findViewById(R.id.checkBox);
        signupButton = findViewById(R.id.signupbutton);
        backButton = findViewById(R.id.imageButton4);
        chooseImageButton = findViewById(R.id.chooseImageButton);
    }

    private void signUp() {
        if (validateInput()) {
            String password = passwordEditText.getText().toString();
            String repassword = repasswordEditText.getText().toString();
            String pin = pinEditText.getText().toString();
            String repin = repinEditText.getText().toString();

            if (!password.equals(repassword)) {
                showToast("Passwords do not match");
                return;
            }

            if (!pin.equals(repin)) {
                showToast("PINs do not match");
                return;
            }

            String hashedPin = hashPin(pin);

            mAuth.createUserWithEmailAndPassword(emailEditText.getText().toString(), password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser firebaseUser = mAuth.getCurrentUser();
                            if (firebaseUser != null) {
                                try {
                                    String userId = firebaseUser.getUid();
                                    Map<String, Object> userData = new HashMap<>();
                                    userData.put("firstName", firstNameEditText.getText().toString());
                                    userData.put("lastName", lastNameEditText.getText().toString());
                                    userData.put("email", emailEditText.getText().toString());

                                    // Encrypt birthdate before storing
                                    String hashedBirthdate = encrypt(birthdateEditText.getText().toString());
                                    userData.put("birthdate", hashedBirthdate);

                                    userData.put("phoneNumber", phoneNumberEditText.getText().toString());
                                    userData.put("pin", hashedPin);

                                    if (selectedImageUri != null) {
                                        StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("user_images").child(userId);
                                        storageRef.putFile(selectedImageUri)
                                                .addOnSuccessListener(taskSnapshot -> storageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                                                    String imageUrl = uri.toString();
                                                    userData.put("imageUri", imageUrl);

                                                    rootDatabaseRef.child("Users").child(userId).setValue(userData)
                                                            .addOnCompleteListener(databaseTask -> {
                                                                if (databaseTask.isSuccessful()) {
                                                                    showToast("User registered successfully");
                                                                    Intent intent = new Intent(signup.this, MainActivity.class);
                                                                    startActivity(intent);
                                                                    finish();
                                                                } else {
                                                                    showToast("Failed to register user in database");
                                                                    firebaseUser.delete();
                                                                }
                                                            });
                                                }))
                                                .addOnFailureListener(e -> showToast("Failed to upload image"));
                                    } else {
                                        rootDatabaseRef.child("Users").child(userId).setValue(userData)
                                                .addOnCompleteListener(databaseTask -> {
                                                    if (databaseTask.isSuccessful()) {
                                                        showToast("User registered successfully");
                                                        Intent intent = new Intent(signup.this, MainActivity.class);
                                                        startActivity(intent);
                                                        finish();
                                                    } else {
                                                        showToast("Failed to register user in database");
                                                        firebaseUser.delete();
                                                    }
                                                });
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    showToast("Error encrypting data");
                                }
                            }
                        } else {
                            showToast("Failed to register user");
                        }
                    });
        }
    }

    private String hashPin(String pin) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(pin.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private String encrypt(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private boolean validateInput() {
        if (firstNameEditText.getText().toString().isEmpty()) {
            showToast("First Name is required");
            return false;
        }
        if (lastNameEditText.getText().toString().isEmpty()) {
            showToast("Last Name is required");
            return false;
        }
        if (emailEditText.getText().toString().isEmpty()) {
            showToast("Email is required");
            return false;
        }
        if (phoneNumberEditText.getText().toString().isEmpty()) {
            showToast("Phone Number is required");
            return false;
        }
        String birthdate = birthdateEditText.getText().toString();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(birthdate);
        } catch (ParseException e) {
            showToast("Birthdate must be in MM/DD/YYYY format");
            return false;
        }
        if (!agreeCheckBox.isChecked()) {
            showToast("You must agree to the terms.");
            return false;
        }
        return true;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
        }
    }
}