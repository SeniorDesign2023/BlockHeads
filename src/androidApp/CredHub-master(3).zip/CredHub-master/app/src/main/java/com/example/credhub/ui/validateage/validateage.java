package com.example.credhub.ui.validateage;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.credhub.MainActivity;
import com.example.credhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;

public class validateage extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, driversLicenceEditText, birthdateEditText, expirationDateEditText;
    private Spinner stateSpinner;
    private String userID;
    private RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validateage);

        // Initialize Volley request queue
        queue = Volley.newRequestQueue(this);

        // Attempt to retrieve the userID passed to this activity, fallback to FirebaseAuth if not present
        userID = getIntent().getStringExtra("userID");
        if (userID == null) {
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
            if (currentUser != null) {
                userID = currentUser.getUid();
            } else {
                Toast.makeText(this, "Error: User not logged in.", Toast.LENGTH_LONG).show();
                finish(); // Close the activity if there's no user ID
                return;
            }
        }

        // Initialize Views
        initializeViews();

        // Submit Button OnClickListener
        Button submitButton = findViewById(R.id.submitbutton);
        submitButton.setOnClickListener(v -> {
            if (validateInput()) {
                sendRequest();
            }
        });

        // Back Button OnClickListener
        ImageButton backButton = findViewById(R.id.imageButton4);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(validateage.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

    }

    private void initializeViews() {
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        driversLicenceEditText = findViewById(R.id.driverLicenseEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        expirationDateEditText = findViewById(R.id.expirationDateEditText);
        stateSpinner = findViewById(R.id.stateSpinner);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"Select a State", "WY"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stateSpinner.setAdapter(adapter);
        stateSpinner.setSelection(0);
    }

    private boolean validateInput() {
        // Input validation checks
        if (isEmpty(firstNameEditText, "First Name is required") ||
                isEmpty(lastNameEditText, "Last Name is required") ||
                isEmpty(driversLicenceEditText, "Driver License is required") ||
                isEmpty(birthdateEditText, "Birthdate is required") ||
                isEmpty(expirationDateEditText, "Expiration Date is required") ||
                stateSpinner.getSelectedItemPosition() == 0) {
            return false;
        }

        // Date format validation
        if (!isValidDate(birthdateEditText.getText().toString()) ||
                !isValidDate(expirationDateEditText.getText().toString())) {
            showToast("Dates must be in MM/DD/YYYY format");
            return false;
        }

        return true; // All validations passed
    }

    private boolean isEmpty(EditText editText, String errorMessage) {
        if (editText.getText().toString().trim().isEmpty()) {
            showToast(errorMessage);
            editText.requestFocus();
            return true;
        }
        return false;
    }

    private boolean isValidDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private String hashSHA256(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(value.getBytes());
            StringBuilder hashStringBuilder = new StringBuilder();
            for (byte hashByte : hashBytes) {
                String hex = Integer.toHexString(0xff & hashByte);
                if (hex.length() == 1) {
                    hashStringBuilder.append('0');
                }
                hashStringBuilder.append(hex);
            }
            return hashStringBuilder.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void sendRequest() {
        // Prepare JSON request body
        String url = "https://credhub.azurewebsites.net/validateAge";
        String requestBody = "{\"firstName\":\"" + firstNameEditText.getText().toString() + "\","
                + "\"lastName\":\"" + lastNameEditText.getText().toString() + "\","
                + "\"birthDate\":\"" + birthdateEditText.getText().toString() + "\","
                + "\"dlNumber\":\"" + driversLicenceEditText.getText().toString() + "\","
                + "\"expirationDate\":\"" + expirationDateEditText.getText().toString() + "\","
                + "\"state\":\"" + stateSpinner.getSelectedItem().toString() + "\"}";

        // Use StringRequest to handle plain text response
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        boolean validationResult = Boolean.parseBoolean(response);
                        sendToFirebase(validationResult);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        showToast("Request failed: " + error.toString());
                    }
                }) {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }

            @Override
            public byte[] getBody() {
                try {
                    return requestBody == null ? null : requestBody.getBytes("utf-8");
                } catch (UnsupportedEncodingException uee) {
                    showToast("Unsupported Encoding: " + uee.getMessage());
                    return null;
                }
            }
        };

        queue.add(stringRequest);
    }

    private void sendToFirebase(boolean validationResult) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("AgeValidation");

        HashMap<String, Object> dataMap = new HashMap<>();
        dataMap.put("firstName", firstNameEditText.getText().toString());
        dataMap.put("lastName", lastNameEditText.getText().toString());
        dataMap.put("driversLicense", hashSHA256(driversLicenceEditText.getText().toString())); // Hash driver's license number
        dataMap.put("birthdate", hashSHA256(birthdateEditText.getText().toString())); // Hash birthdate
        dataMap.put("expirationDate", hashSHA256(expirationDateEditText.getText().toString())); // Hash expiration date
        dataMap.put("state", stateSpinner.getSelectedItem().toString());
        dataMap.put("ageValidated", validationResult);

        databaseReference.child(userID).setValue(dataMap)
                .addOnSuccessListener(aVoid -> {
                    showToast("Age validation data saved successfully.");
                    Intent intent = new Intent(validateage.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    showToast("Failed to save age validation data. Please try again.");
                });
    }
}
