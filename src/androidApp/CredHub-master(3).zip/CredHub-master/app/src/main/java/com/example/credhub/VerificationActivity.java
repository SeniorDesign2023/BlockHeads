package com.example.credhub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class VerificationActivity extends AppCompatActivity {

    private EditText editTextVerificationCode;
    private Button buttonVerify;
    private Button cancelButton; // Add reference for the cancel button
    private FirebaseAuth mAuth;
    private DatabaseReference userCodeRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        mAuth = FirebaseAuth.getInstance();
        String userID = mAuth.getCurrentUser().getUid();
        userCodeRef = FirebaseDatabase.getInstance().getReference("UserCodes").child(userID);

        editTextVerificationCode = findViewById(R.id.editTextVerificationCode);
        buttonVerify = findViewById(R.id.buttonVerify);
        cancelButton = findViewById(R.id.buttonCancel); // Initialize the cancel button

        // Set OnClickListener for the cancel button
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the mainload activity
                Intent intent = new Intent(VerificationActivity.this, mainload.class);
                startActivity(intent);
                finish(); // Finish this activity to prevent the user from navigating back to it
            }
        });

        // Setting OnClickListener for the verify button
        buttonVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered verification code
                String enteredCode = editTextVerificationCode.getText().toString();

                // Retrieve the correct verification code from the database
                userCodeRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            String correctCode = dataSnapshot.getValue(String.class);
                            if (correctCode != null && enteredCode.equals(correctCode)) {
                                // If correct, navigate to MainActivity
                                Intent intent = new Intent(VerificationActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish(); // Finish this activity to prevent the user from navigating back to it
                            } else {
                                // If incorrect, show a toast message
                                Toast.makeText(VerificationActivity.this, "Incorrect verification code", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // If no verification code found, show a toast message
                            Toast.makeText(VerificationActivity.this, "No verification code found", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // If error occurs, show a toast message
                        Toast.makeText(VerificationActivity.this, "Failed to retrieve verification code", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
