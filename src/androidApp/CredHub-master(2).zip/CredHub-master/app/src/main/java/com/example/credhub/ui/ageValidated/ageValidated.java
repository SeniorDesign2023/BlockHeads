package com.example.credhub.ui.ageValidated;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.credhub.MainActivity;
import com.example.credhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ageValidated extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age_validated);

        ImageButton backButton = findViewById(R.id.imageButton4);
        ImageView userImageView = findViewById(R.id.imagePerson);
        ImageView approveOrNotImageView = findViewById(R.id.approveornot);

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(ageValidated.this, MainActivity.class);
            startActivity(intent);
        });

        populateUserData(userImageView, approveOrNotImageView);
    }

    private void populateUserData(final ImageView userImageView, final ImageView approveOrNotImageView) {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference().child("Users").child(userId);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        String imageUrl = dataSnapshot.child("imageUri").getValue(String.class);
                        Glide.with(ageValidated.this)
                                .load(imageUrl)
                                .placeholder(R.mipmap.image_logo)
                                .error(R.mipmap.image_logo)
                                .into(userImageView);

                        String storedHashedBirthdate = dataSnapshot.child("birthdate").getValue(String.class);
                        // Retrieve user's birthdate input (replace "userInputBirthdate" with actual input)
                        String userInputBirthdate = "userInputBirthdate";
                        String hashedUserInputBirthdate = hashString(userInputBirthdate);

                        // Compare hashed values
                        if (storedHashedBirthdate != null && storedHashedBirthdate.equals(hashedUserInputBirthdate)) {
                            int age = getAgeFromBirthdate(userInputBirthdate);
                            boolean is21OrOver = age >= 21;
                            boolean ageValidated = dataSnapshot.child("ageValidated").getValue(Boolean.class); // Check if "ageValidated" exists

                            if (ageValidated && is21OrOver) {
                                approveOrNotImageView.setImageResource(R.drawable.checkmark); // Green check
                            } else {
                                approveOrNotImageView.setImageResource(R.drawable.redx); // Red X
                            }
                            approveOrNotImageView.setVisibility(View.VISIBLE);
                        }
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Handle possible errors
                }
            });
        }
    }

    // Hashing function using SHA-256
    private String hashString(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private int getAgeFromBirthdate(String birthdateStr) {
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        try {
            Date birthdate = format.parse(birthdateStr);
            Calendar birth = Calendar.getInstance();
            birth.setTime(birthdate);
            Calendar today = Calendar.getInstance();
            int age = today.get(Calendar.YEAR) - birth.get(Calendar.YEAR);
            if (today.get(Calendar.MONTH) < birth.get(Calendar.MONTH) ||
                    (today.get(Calendar.MONTH) == birth.get(Calendar.MONTH) &&
                            today.get(Calendar.DAY_OF_MONTH) < birth.get(Calendar.DAY_OF_MONTH))) {
                age--;
            }
            return age;
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
