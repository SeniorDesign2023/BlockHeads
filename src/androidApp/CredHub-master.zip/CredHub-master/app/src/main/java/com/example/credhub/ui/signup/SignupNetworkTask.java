package com.example.credhub.ui.signup;

import android.os.AsyncTask;
import android.util.Log;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.mindrot.jbcrypt.BCrypt;

public class SignupNetworkTask extends AsyncTask<Void, Void, Boolean> {

    private static final String TAG = SignupNetworkTask.class.getSimpleName();

    // Database credentials
    private static final String DB_URL = "jdbc:postgresql://chpg.chokecawk3n4.us-east-1.rds.amazonaws.com:5432/chpg";
    private static final String USER = "postgres";
    private static final String PASS = "CredHub*2024";

    // Sign-up data
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String birthdate;
    private String username;
    private String password;
    private String pin;
    private boolean agreeCheckBox;

    // Constructor for user account table
    public SignupNetworkTask(String firstName, String lastName, String email, String phoneNumber,
                             String birthdate, boolean agreeCheckBox) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.birthdate = birthdate;
        this.agreeCheckBox = agreeCheckBox;
    }

    // Constructor for user auth table
    public SignupNetworkTask(String email, String username, String password, String pin) {
        this.email = email;
        this.username = username;
        this.password = password;
        this.pin = pin;
    }

    @Override
    protected Boolean doInBackground(Void... voids) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            // Register JDBC driver
            Class.forName("org.postgresql.Driver");
            // Open a connection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            // Execute a query
            if (username != null && password != null) {
                String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
                String hashedPin = BCrypt.hashpw(pin, BCrypt.gensalt());
                String sql = "INSERT INTO user_auth (email, username, passwrd, pincode) VALUES (?, ?, ?, ?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, email);
                stmt.setString(2, username);
                stmt.setString(3, hashedPassword);
                stmt.setString(4, hashedPin);
            } else {
                String sql = "INSERT INTO user_account (first_name, last_name, email, phone_number, birthdate, i_agreed) VALUES (?, ?, ?, ?, ?, ?)";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, firstName);
                stmt.setString(2, lastName);
                stmt.setString(3, email);
                stmt.setString(4, phoneNumber);
                stmt.setString(5, birthdate);
                stmt.setBoolean(6, agreeCheckBox);
            }
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException | ClassNotFoundException e) {
            Log.e(TAG, "Error in database operation", e);
            return false;
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                Log.e(TAG, "Error closing database connection", e);
            }
        }
    }
}
