package com.example.credhub;

import retrofit2.Call;
import retrofit2.http.GET;

public interface UserService {
    @GET("userinfo") // Adjust this endpoint as necessary
    Call<User> getUserInfo();
}
