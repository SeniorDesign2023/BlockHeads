package com.example.credhub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class validatedegree extends AppCompatActivity {

    private EditText birthdateEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validatedegree);

        // Initialize Spinner
        Spinner degreeTypeSpinner = findViewById(R.id.degreeTypeSpinner);

        // Define degree types array with the initial prompt
        String[] degreeTypes = {"Select a Degree type", "Bachelor's Science", "Associates Science", "Associates Arts",
                "Bachelor's Arts", "Master's Science", "Master's Arts", "PhD", "DR"};

        // Set up adapter for the Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, degreeTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        degreeTypeSpinner.setAdapter(adapter);

        // Set initial selection to the prompt
        degreeTypeSpinner.setSelection(0);

        // Find the Button by its id
        Button submitButton = findViewById(R.id.submitbutton);

        // Set OnClickListener for the sign-up button
        submitButton.setOnClickListener(v -> {
            if(validateInput()) {
                Intent intent = new Intent(validatedegree.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Find the ImageButton for the back button
        ImageButton backButton = findViewById(R.id.imageButton4);

        // Set OnClickListener for the ImageButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the current activity and return to the previous one
                finish();
            }
        });
    }

    private void initializeViews() {
        birthdateEditText = findViewById(R.id.birthdateEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        EditText repasswordEditText = findViewById(R.id.repassword);

        // Set transformation method to show dots instead of actual characters
        passwordEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
        repasswordEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
    }

    private boolean validateInput() {
        EditText firstNameEditText = findViewById(R.id.firstNameEditText);
        EditText lastNameEditText = findViewById(R.id.lastNameEditText);
        EditText schoolIdEditText = findViewById(R.id.schoolIdEditText);
        EditText birthdateEditText = findViewById(R.id.birthdateEditText);
        EditText universityEditText = findViewById(R.id.universityEditText);
        Spinner degreeTypeSpinner = findViewById(R.id.degreeTypeSpinner);
        EditText degreeAwardedEditText = findViewById(R.id.degreeAwardedEditText);
        EditText yearAchivedEditText = findViewById(R.id.yearAchivedEditText);

        // Check if any of the input fields are empty
        if (firstNameEditText.getText().toString().isEmpty()) {
            showToast("First Name is required");
            firstNameEditText.requestFocus();
            return false;
        }
        if (lastNameEditText.getText().toString().isEmpty()) {
            showToast("Last Name is required");
            lastNameEditText.requestFocus();
            return false;
        }
        if (birthdateEditText.getText().toString().isEmpty()) {
            showToast("Birthdate is required");
            birthdateEditText.requestFocus();
            return false;
        }
        if (schoolIdEditText.getText().toString().isEmpty()) {
            showToast("Driver License is required");
            schoolIdEditText.requestFocus();
            return false;
        }
        if (universityEditText.getText().toString().isEmpty()) {
            showToast("Expiration Date is required");
            universityEditText.requestFocus();
            return false;
        }
        if (degreeTypeSpinner.getSelectedItemPosition() <= 0) {
            showToast("State is required");
            degreeTypeSpinner.requestFocus();
            return false;
        }
        if (degreeAwardedEditText.getText().toString().isEmpty()) {
            showToast("Driver License is required");
            degreeAwardedEditText.requestFocus();
            return false;
        }
        if (yearAchivedEditText.getText().toString().isEmpty()) {
            showToast("Expiration Date is required");
            universityEditText.requestFocus();
            return false;
        }
        // Check if birthdate is in MM/DD/YYYY format
        String birthdate = birthdateEditText.getText().toString();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(birthdate);
        } catch (ParseException e) {
            showToast("Birthdate must be in MM/DD/YYYY format");
            return false;
        }
        return true;
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
