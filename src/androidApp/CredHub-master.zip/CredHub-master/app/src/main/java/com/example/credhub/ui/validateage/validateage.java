package com.example.credhub.ui.validateage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.credhub.MainActivity;
import com.example.credhub.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class validateage extends AppCompatActivity {

    private EditText birthdateEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validateage);

        ImageButton backButton = findViewById(R.id.imageButton4);
        // Set OnClickListener for the ImageButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Correct approach would be to replace the fragment or navigate appropriately
                finish(); // Consider using finish() to return to the previous Activity, or properly manage fragment transactions.
            }
        });

        Spinner stateSpinner = findViewById(R.id.stateSpinner);
        // Define state types array with the initial prompt
        String[] stateTypes = {"Select a State ", "WY"};

        // Set up adapter for the Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(validateage.this,
                android.R.layout.simple_spinner_item, stateTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stateSpinner.setAdapter(adapter);

        // Set initial selection to the prompt
        stateSpinner.setSelection(0);

        Button submitButton = findViewById(R.id.submitbutton);
        // Set OnClickListener for the sign-up button
        submitButton.setOnClickListener(v -> {
           if(validateInputs()) {
               Intent intent = new Intent(validateage.this, MainActivity.class);
               startActivity(intent);
           }
        });
    }
    private void initializeViews() {
        birthdateEditText = findViewById(R.id.birthdateEditText);
        EditText passwordEditText = findViewById(R.id.passwordEditText);
        EditText repasswordEditText = findViewById(R.id.repassword);

        // Set transformation method to show dots instead of actual characters
        passwordEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
        repasswordEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
    }

    private boolean validateInputs() {
        EditText firstNameEditText = findViewById(R.id.firstNameEditText);
        EditText lastNameEditText = findViewById(R.id.lastNameEditText);
        EditText driverLicenseEditText = findViewById(R.id.driverLicenseEditText);
        Spinner stateSpinner = findViewById(R.id.stateSpinner);
        EditText birthdateEditText = findViewById(R.id.birthdateEditText);
        EditText expirationDateEditText = findViewById(R.id.expirationDateEditText);

        // Check if any of the input fields are empty
        if (firstNameEditText.getText().toString().isEmpty()) {
            showToast("First Name is required");
            firstNameEditText.requestFocus();
            return false;
        }
        if (lastNameEditText.getText().toString().isEmpty()) {
            showToast("Last Name is required");
            lastNameEditText.requestFocus();
            return false;
        }
        if (birthdateEditText.getText().toString().isEmpty()) {
            showToast("Birthdate is required");
            birthdateEditText.requestFocus();
            return false;
        }
        if (driverLicenseEditText.getText().toString().isEmpty()) {
            showToast("Driver License is required");
            driverLicenseEditText.requestFocus();
            return false;
        }
        if (expirationDateEditText.getText().toString().isEmpty()) {
            showToast("Expiration Date is required");
            expirationDateEditText.requestFocus();
            return false;
        }
        if (stateSpinner.getSelectedItemPosition() <= 0) {
            showToast("State is required");
            stateSpinner.requestFocus();
            return false;
        }

        // Check if birthdate is in MM/DD/YYYY format
        String birthdate = birthdateEditText.getText().toString();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(birthdate);
        } catch (ParseException e) {
            showToast("Birthdate must be in MM/DD/YYYY format");
            birthdateEditText.requestFocus();
            return false;
        }

        String expirationDate = expirationDateEditText.getText().toString();
        try {
            dateFormat.parse(expirationDate);
        } catch (ParseException e) {
            showToast("Expiration Date must be in MM/DD/YYYY format");
            expirationDateEditText.requestFocus();
            return false;
        }
        return true;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
