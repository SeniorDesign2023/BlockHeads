package com.example.credhub.ui.home;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.credhub.MainActivity;
import com.example.credhub.R;
import com.example.credhub.ageValidated;
import com.example.credhub.databinding.FragmentHomeBinding;
import com.example.credhub.degree_validated;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Button degreeButton = root.findViewById(R.id.degreebutton);
        Button ageButton = root.findViewById(R.id.agebutton);

        degreeButton.setOnClickListener(v -> showPinEntryDialog(this::navigateToDegreeValidatedActivity));
        ageButton.setOnClickListener(v -> showPinEntryDialog(this::navigateToAgeValidatedActivity));

        return root;
    }

    private void showPinEntryDialog(final Runnable onSuccess) {
        AlertDialog.Builder alert = new AlertDialog.Builder(requireContext());
        final EditText pinInput = new EditText(requireContext());
        pinInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        alert.setTitle("Enter PIN");
        alert.setView(pinInput);
        alert.setPositiveButton("Ok", (dialog, whichButton) -> verifyPin(pinInput.getText().toString(), onSuccess));
        alert.setNegativeButton("Cancel", (dialog, whichButton) -> dialog.dismiss());
        alert.show();
    }

    private void verifyPin(String enteredPin, final Runnable onSuccess) {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(requireContext(), "User not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = currentUser.getUid();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users").child(userId).child("hashedPin");

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String hashedPin = dataSnapshot.getValue(String.class);
                if (hashedPin != null && verifyHashedPin(enteredPin, hashedPin)) {
                    onSuccess.run();
                } else {
                    Toast.makeText(requireContext(), "Incorrect PIN", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(requireContext(), "Error checking PIN", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean verifyHashedPin(String enteredPin, String hashedPin) {
        // Placeholder for your hash verification logic
        // Implement your actual hash function or verification method here
        return hashedPin.equals(hashFunction(enteredPin));
    }

    private String hashFunction(String pin) {
        // Placeholder for your actual hash function
        // Return the hashed version of the input pin
        return pin; // This is just a placeholder. Implement hashing logic as per your requirement.
    }

    private void navigateToDegreeValidatedActivity() {
        Intent intent = new Intent(requireContext(), degree_validated.class);
        startActivity(intent);
    }

    private void navigateToAgeValidatedActivity() {
        Intent intent = new Intent(requireContext(), ageValidated.class);
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
