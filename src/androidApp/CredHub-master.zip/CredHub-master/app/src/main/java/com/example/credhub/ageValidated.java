package com.example.credhub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import org.mindrot.jbcrypt.BCrypt;

public class ageValidated extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age_validated);

            // Find the ImageButton by its id
            ImageButton backButton = findViewById(R.id.imageButton4);

            // Set OnClickListener for the ImageButton
            backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the mainload activity
                Intent intent = new Intent(ageValidated.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public static class PasswordUtils {

        // Hash a password using BCrypt
        public static String hashPassword(String plainTextPassword) {
            return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt());
        }

        // Check if a plaintext password matches a hashed password
        public static boolean checkPassword(String plainTextPassword, String hashedPassword) {
            return BCrypt.checkpw(plainTextPassword, hashedPassword);
        }
    }
}
