package com.example.credhub.ui.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.example.credhub.R;
import com.example.credhub.mainload;
import com.example.credhub.MainActivity;

public class LogIn extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        // Initialize EditText fields
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        // Find the ImageButton by its id
        ImageButton backButton = findViewById(R.id.imageButton4);
        // Set OnClickListener for the ImageButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the mainload activity
                Intent intent = new Intent(LogIn.this, mainload.class);
                startActivity(intent);
            }
        });

        Button signinButton = findViewById(R.id.signinbutton);
        // Set OnClickListener for the sign-in button
        signinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the entered username and password
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                // Check if the entered username and password are in the database
                if (validateUser(username, password)) {
                    // Navigate to the MainActivity if login is successful
                    Intent intent = new Intent(LogIn.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    // Display a message indicating that the username or password is incorrect
                    Toast.makeText(LogIn.this, "Username or password is incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to validate user credentials against the database
    private boolean validateUser(String username, String password) {
        // Initialize connection variables
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establish a connection to the PostgreSQL database
            connection = DriverManager.getConnection("jdbc:postgresql://chpg.chokecawk3n4.us-east-1.rds.amazonaws.com:5432/chpg", "postgres", "CredHub*2024");

            // Define the SQL query to check if the username and password match any records in the database
            String query = "SELECT * FROM user_auth WHERE username = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);

            // Execute the query
            resultSet = preparedStatement.executeQuery();

            // Check if the query returned any rows
            if (resultSet.next()) {
                // If the username exists, retrieve the password from the database
                String dbPassword = resultSet.getString("password");

                // Compare the entered password with the password retrieved from the database
                if (password.equals(dbPassword)) {
                    // If passwords match, return true indicating successful login
                    return true;
                }
            }
            // If no rows were returned or passwords don't match, return false
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Close the database resources
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
