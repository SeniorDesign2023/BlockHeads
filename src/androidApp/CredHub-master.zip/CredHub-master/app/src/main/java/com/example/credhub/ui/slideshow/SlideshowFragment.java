import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.credhub.R;
import com.example.credhub.RetrofitClient;
import com.example.credhub.UserService;
import com.example.credhub.User;
import com.example.credhub.mainload;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SlideshowFragment extends Fragment {

    private ImageView imagePerson;
    private TextView textFullName, textUsername, textEmail, textPhoneNumber;
    private Button signOutButton;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);

        imagePerson = root.findViewById(R.id.imagePerson);
        textFullName = root.findViewById(R.id.textFullName);
        textUsername = root.findViewById(R.id.textUsername);
        textEmail = root.findViewById(R.id.textEmail);
        textPhoneNumber = root.findViewById(R.id.textPhoneNumber);
        signOutButton = root.findViewById(R.id.signOutButton);

        // Call method to fetch user data
        fetchUserData();

        // Set OnClickListener for the sign-out button
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the sign-up activity
                Intent intent = new Intent(getContext(), mainload.class);
                startActivity(intent);
            }
        });

        return root;
    }

    private void fetchUserData() {
        // Assuming you're using Retrofit for network requests
        UserService service = RetrofitClient.getRetrofitInstance().create(UserService.class);
        Call<User> call = service.getUserInfo();
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if (response.isSuccessful()) {
                    User user = response.body();
                    // Update UI with user data
                    if (user != null) {
                        // Set image using Picasso library
//                        Picasso.get().load(user.getImageUrl()).into(imagePerson);
//                        // Set text data
//                        textFullName.setText(user.getFullName());
//                        textUsername.setText(user.getUsername());
//                        textEmail.setText(user.getEmail());
//                        textPhoneNumber.setText(user.getPhoneNumber());
                    }
                }
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                // Handle failure
            }
        });
    }
}
