package com.example.credhub.ui.signup;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.regex.Pattern;

import com.example.credhub.MainActivity;
import com.example.credhub.R;
import com.example.credhub.mainload;

public class signup extends AppCompatActivity {

    private EditText firstNameEditText;
    private EditText lastNameEditText;
    private EditText emailEditText;
    private EditText phoneNumberEditText;
    private EditText birthdateEditText;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText repasswordEditText;
    private EditText pinEditText;
    private EditText repinEditText;
    private CheckBox agreeCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initializeViews();

        ImageButton backButton = findViewById(R.id.imageButton4);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(signup.this, mainload.class);
            startActivity(intent);
        });

        Button signupButton = findViewById(R.id.signupbutton);
        signupButton.setOnClickListener(v -> {
            if (validateInputs() && validatePIN()) {
                SignupNetworkTask userAccountTask = new SignupNetworkTask(firstNameEditText.getText().toString(),
                        lastNameEditText.getText().toString(), emailEditText.getText().toString(),
                        phoneNumberEditText.getText().toString(), birthdateEditText.getText().toString(),
                        agreeCheckBox.isChecked());

                SignupNetworkTask userAuthTask = new SignupNetworkTask(emailEditText.getText().toString(),
                        usernameEditText.getText().toString(), passwordEditText.getText().toString(),
                        pinEditText.getText().toString());

                userAccountTask.execute();
                userAuthTask.execute();

                Intent intent = new Intent(signup.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void initializeViews() {
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        repasswordEditText = findViewById(R.id.repassword);
        pinEditText = findViewById(R.id.pinEditText); // Initialize PIN-related EditText
        repinEditText = findViewById(R.id.repinEditText); // Initialize Re-enter PIN EditText
        agreeCheckBox = findViewById(R.id.checkBox);

        passwordEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
        repasswordEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
    }

    private boolean validateInputs() {
        if (firstNameEditText.getText().toString().isEmpty()) {
            showToast("First Name is required");
            firstNameEditText.requestFocus();
            return false;
        }
        // Similar checks for other fields

        if (!passwordEditText.getText().toString().equals(repasswordEditText.getText().toString())) {
            showToast("Passwords do not match");
            return false;
        }

        String password = passwordEditText.getText().toString();
        if (!Pattern.compile("^(?=.*[0-9])(?=.*[A-Z]).{8,}$").matcher(password).matches()) {
            showToast("Password must be 8 characters or more with at least one capital letter and a number");
            return false;
        }

        String birthdate = birthdateEditText.getText().toString();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(birthdate);
        } catch (ParseException e) {
            showToast("Birthdate must be in MM/DD/YYYY format");
            birthdateEditText.requestFocus();
            return false;
        }

        if (!agreeCheckBox.isChecked()) {
            showToast("You must agree to the terms");
            agreeCheckBox.requestFocus();
            return false;
        }

        return true;
    }

    private boolean validatePIN() {
        String pin = pinEditText.getText().toString();
        String repin = repinEditText.getText().toString();

        if (pin.isEmpty() || repin.isEmpty()) {
            showToast("Both PIN fields are required");
            return false;
        } else if (!pin.equals(repin)) {
            showToast("PINs do not match");
            return false;
        } else if (pin.length() != 4) {
            showToast("PIN must be 4 digits long");
            return false;
        }

        return true;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
