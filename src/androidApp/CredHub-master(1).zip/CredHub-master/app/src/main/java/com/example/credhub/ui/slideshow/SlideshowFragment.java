package com.example.credhub.ui.slideshow;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.credhub.R;
import com.example.credhub.mainload;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SlideshowFragment extends Fragment {

    private ImageView imagePerson;
    private TextView textFullName, textUsername, textEmail, textPhoneNumber;
    private Button signOutButton;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);

        imagePerson = root.findViewById(R.id.imagePerson);
        textFullName = root.findViewById(R.id.textFullName);
        textUsername = root.findViewById(R.id.textUsername);
        textEmail = root.findViewById(R.id.textEmail);
        textPhoneNumber = root.findViewById(R.id.textPhoneNumber);
        signOutButton = root.findViewById(R.id.signOutButton);

        // Call method to fetch user data

        // Set OnClickListener for the sign-out button
        signOutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the sign-up activity
                Intent intent = new Intent(getContext(), mainload.class);
                startActivity(intent);
            }
        });

        return root;
    }


}
