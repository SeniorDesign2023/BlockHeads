package com.example.credhub.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.credhub.R;
import com.example.credhub.ui.degreeValidated.degree_validated;
import com.example.credhub.ui.ageValidated.ageValidated;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.example.credhub.databinding.FragmentHomeBinding;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        Button degreeButton = root.findViewById(R.id.degreebutton);
        Button ageButton = root.findViewById(R.id.agebutton);

        degreeButton.setOnClickListener(v -> showPinEntryDialog(this::navigateToDegreeValidatedActivity));
        ageButton.setOnClickListener(v -> showPinEntryDialog(this::navigateToAgeValidatedActivity));

        return root;
    }

    private void showPinEntryDialog(final Runnable onSuccess) {
        AlertDialog.Builder alert = new AlertDialog.Builder(requireContext());
        final EditText pinInput = new EditText(requireContext());
        pinInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        alert.setTitle("Enter PIN");
        alert.setView(pinInput);
        alert.setPositiveButton("Ok", (dialog, whichButton) -> verifyPin(pinInput.getText().toString(), onSuccess));
        alert.setNegativeButton("Cancel", (dialog, whichButton) -> dialog.dismiss());
        alert.show();
    }

    private void verifyPin(String enteredPin, final Runnable onSuccess) {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(requireContext(), "User not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = currentUser.getUid();
        DatabaseReference pinRef = FirebaseDatabase.getInstance().getReference("Users").child(userId).child("pin");

        pinRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String hashedPin = dataSnapshot.getValue(String.class);
                Log.d("PIN", "Retrieved hashedPin: " + hashedPin); // Debug log to check hashed pin
                if (hashedPin != null && verifyHashedPin(enteredPin, hashedPin)) {
                    onSuccess.run();
                } else {
                    Toast.makeText(requireContext(), "Incorrect PIN", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(requireContext(), "Error checking PIN", Toast.LENGTH_SHORT).show();
                Log.e("PIN", "Database error: " + databaseError.getMessage()); // Log database error
            }
        });
    }

    private boolean verifyHashedPin(String enteredPin, String hashedPin) {
        // Hash the entered pin and compare with the stored hashed pin
        String enteredPinHash = hashPin(enteredPin);
        return enteredPinHash != null && enteredPinHash.equals(hashedPin);
    }

    private String hashPin(String pin) {
        try {
            // Create SHA-256 Hash
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(pin.getBytes());

            // Convert byte array to hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void navigateToDegreeValidatedActivity() {
        Intent intent = new Intent(requireContext(), degree_validated.class);
        startActivity(intent);
    }

    private void navigateToAgeValidatedActivity() {
        Intent intent = new Intent(requireContext(), ageValidated.class);
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
