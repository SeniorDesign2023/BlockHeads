package com.example.credhub.ui.signup;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.credhub.R;
import com.example.credhub.MainActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class signup extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, emailEditText, phoneNumberEditText, birthdateEditText, usernameEditText, passwordEditText, repasswordEditText, pinEditText, repinEditText;
    private CheckBox agreeCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initializeViews();

        ImageButton backButton = findViewById(R.id.imageButton4);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(signup.this, MainActivity.class); // Assuming MainActivity is the correct back destination
            startActivity(intent);
        });

        Button signupButton = findViewById(R.id.signupbutton);
        signupButton.setOnClickListener(v -> {
            if (validateInputs() && validatePIN()) {
                try {
                    JSONObject userData = new JSONObject();
                    userData.put("first_name", firstNameEditText.getText().toString());
                    userData.put("last_name", lastNameEditText.getText().toString());
                    userData.put("email", emailEditText.getText().toString());
                    userData.put("birthdate", birthdateEditText.getText().toString());
                    userData.put("phone_number", phoneNumberEditText.getText().toString());
                    userData.put("i_agree", agreeCheckBox.isChecked());

                    sendDataToServer(userData);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void initializeViews() {
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        repasswordEditText = findViewById(R.id.repasswordEditText);
        pinEditText = findViewById(R.id.pinEditText);
        repinEditText = findViewById(R.id.repinEditText);
        agreeCheckBox = findViewById(R.id.checkBox);

        // Assuming you want to hide passwords and PINs as they are entered
        passwordEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
        repasswordEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
        pinEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
        repinEditText.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
    }

    private boolean validateInputs() {
        // Validation logic here (corrected copy-paste errors in messages)
        return true; // Placeholder return value; implement validation logic
    }

    private boolean validatePIN() {
        // PIN validation logic here
        return true; // Placeholder return value; implement validation logic
    }

    private void sendDataToServer(JSONObject userData) {
        OkHttpClient client = new OkHttpClient();

        MediaType MEDIA_TYPE = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(MEDIA_TYPE, userData.toString());

        Request request = new Request.Builder()
                .url("postgresql://postgres:CredHub*2024@chpg.chokecawk3n4.us-east-1.rds.amazonaws.com:5432/chpg")
                .post(body)
                .header("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> showToast("Failed to connect to the server"));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    runOnUiThread(() -> {
                        showToast("User registered successfully");
                        Intent intent = new Intent(signup.this, MainActivity.class);
                        startActivity(intent);
                    });
                } else {
                    runOnUiThread(() -> showToast("Failed to register user"));
                }
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
