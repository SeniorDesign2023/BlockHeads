package com.example.credhub.ui.ageValidated;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.credhub.MainActivity;
import com.example.credhub.R;
public class ageValidated extends AppCompatActivity {

    private boolean isAgeValidated; // Variable to store age validation status

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age_validated);

        // Find views by their IDs
        ImageButton backButton = findViewById(R.id.imageButton4);
        ImageView userImageView = findViewById(R.id.imagePerson); // Use imagePlaceholder1
        ImageView approveOrNotImageView = findViewById(R.id.approveornot);

        // Set OnClickListener for the ImageButton
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the MainActivity
                Intent intent = new Intent(com.example.credhub.ui.ageValidated.ageValidated.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Load user image (You need to implement this)
        // Assuming you have a method to load user image, replace 'loadUserImage()' with your implementation
        //String imageUrl = loadUserImage().child("imageUri").getValue(String.class);

        // Set age validation status (true or false)
        isAgeValidated = true; // Example: You need to determine the validation status

        // Update the TextView based on age validation status
        if (isAgeValidated) {
            approveOrNotImageView.setImageResource(R.drawable.checkmark); // Set green check image
        } else {
            approveOrNotImageView.setImageResource(R.drawable.redx); // Set red X image
        }
    }

    // Method to load user image
    private void loadUserImage(ImageView imageView, String imageUrl) {
        Glide.with(this)
                .load(imageUrl)
                .placeholder(R.mipmap.image_logo) // Placeholder image while loading
                .error(R.mipmap.image_logo) // Error image if loading fails
                .into(imageView);
    }
}

