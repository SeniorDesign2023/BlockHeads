package com.example.credhub.ui.validateage;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.credhub.MainActivity;
import com.example.credhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;

public class validateage extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, driversLicenceEditText, birthdateEditText, expirationDateEditText;
    private Spinner stateSpinner;
    private String userID; // Variable to store the userID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validateage);

        // Attempt to retrieve the userID passed to this activity, fallback to FirebaseAuth if not present
        userID = getIntent().getStringExtra("userID");
        if (userID == null) {
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
            if (currentUser != null) {
                userID = currentUser.getUid();
            } else {
                Toast.makeText(this, "Error: User not logged in.", Toast.LENGTH_LONG).show();
                finish(); // Close the activity if there's no user ID
                return;
            }
        }

        // Initialize Views
        initializeViews();

        // Submit Button OnClickListener
        Button submitButton = findViewById(R.id.submitbutton);
        submitButton.setOnClickListener(v -> {
            if (validateInput()) {
                sendToFirebase();
            }
        });

        // Back Button OnClickListener
        ImageButton backButton = findViewById(R.id.imageButton4);
        backButton.setOnClickListener(v -> finish());
    }


    private void initializeViews() {
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        driversLicenceEditText = findViewById(R.id.driverLicenseEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        expirationDateEditText = findViewById(R.id.expirationDateEditText);
        stateSpinner = findViewById(R.id.stateSpinner);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"Select a State", "WY"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stateSpinner.setAdapter(adapter);
        stateSpinner.setSelection(0);
    }

    private boolean validateInput() {
        // Input validation checks
        if (isEmpty(firstNameEditText, "First Name is required") ||
                isEmpty(lastNameEditText, "Last Name is required") ||
                isEmpty(driversLicenceEditText, "Driver License is required") ||
                isEmpty(birthdateEditText, "Birthdate is required") ||
                isEmpty(expirationDateEditText, "Expiration Date is required") ||
                stateSpinner.getSelectedItemPosition() == 0) {
            return false; // One or more fields are invalid
        }

        // Date format validation
        if (!isValidDate(birthdateEditText.getText().toString()) ||
                !isValidDate(expirationDateEditText.getText().toString())) {
            showToast("Dates must be in MM/DD/YYYY format");
            return false;
        }

        return true; // All validations passed
    }

    private boolean isEmpty(EditText editText, String errorMessage) {
        if (editText.getText().toString().trim().isEmpty()) {
            showToast(errorMessage);
            editText.requestFocus();
            return true;
        }
        return false;
    }

    private boolean isValidDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    private void sendToFirebase() {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("AgeValidation");

        HashMap<String, Object> dataMap = new HashMap<>();
        dataMap.put("firstName", firstNameEditText.getText().toString());
        dataMap.put("lastName", lastNameEditText.getText().toString());
        dataMap.put("driversLicense", driversLicenceEditText.getText().toString());
        dataMap.put("birthdate", birthdateEditText.getText().toString());
        dataMap.put("expirationDate", expirationDateEditText.getText().toString());
        dataMap.put("state", stateSpinner.getSelectedItem().toString());

        databaseReference.child(userID).setValue(dataMap)
                .addOnSuccessListener(aVoid -> {
                    showToast("Age validation data saved successfully.");
                    Intent intent = new Intent(validateage.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    showToast("Failed to save age validation data. Please try again.");
                });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
