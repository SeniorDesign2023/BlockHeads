package com.example.credhub.ui.validateage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.credhub.MainActivity;
import com.example.credhub.R;
import com.example.credhub.validatedegree;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class validateage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validateage);

        Spinner degreeTypeSpinner = findViewById(R.id.stateSpinner);
        String[] stateTypes = {"Select a State", "WY"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, stateTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        degreeTypeSpinner.setAdapter(adapter);
        degreeTypeSpinner.setSelection(0);

        Button submitButton = findViewById(R.id.submitbutton);

        // Set OnClickListener for the sign-up button
        submitButton.setOnClickListener(v -> {
            if(validateInput()) {
                Intent intent = new Intent(validateage.this, MainActivity.class);
                startActivity(intent);
            }
        });

        ImageButton backButton = findViewById(R.id.imageButton4);
        backButton.setOnClickListener(v -> finish());
    }

    private boolean validateInput() {
        EditText firstNameEditText = findViewById(R.id.firstNameEditText);
        EditText lastNameEditText = findViewById(R.id.lastNameEditText);
        EditText driverLicenseEditText = findViewById(R.id.driverLicenseEditText);
        EditText birthdateEditText = findViewById(R.id.birthdateEditText);
        EditText expirationDateEditText = findViewById(R.id.expirationDateEditText);
        Spinner stateSpinner = findViewById(R.id.stateSpinner);

        if (firstNameEditText.getText().toString().isEmpty() ||
                lastNameEditText.getText().toString().isEmpty() ||
                birthdateEditText.getText().toString().isEmpty() ||
                driverLicenseEditText.getText().toString().isEmpty() ||
                expirationDateEditText.getText().toString().isEmpty() ||
                stateSpinner.getSelectedItemPosition() <= 0) {
            showToast("All fields are required and must be filled correctly.");
            return false;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(birthdateEditText.getText().toString());
        } catch (ParseException e) {
            showToast("Birthdate must be in MM/DD/YYYY format");
            birthdateEditText.requestFocus();
            return false;
        }
        return true;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
