package com.example.credhub.ui.validatedegree;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.credhub.MainActivity;
import com.example.credhub.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;

public class validatedegree extends AppCompatActivity {

    private EditText firstNameEditText, lastNameEditText, schoolIdEditText, birthdateEditText, universityEditText, degreeAwardedEditText, yearAchievedEditText;
    private Spinner degreeTypeSpinner;
    private String userID; // Variable to store the userID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_validatedegree);

        // Attempt to retrieve the userID passed to this activity, fallback to FirebaseAuth if not present
        userID = getIntent().getStringExtra("userID");
        if (userID == null) {
            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
            if (currentUser != null) {
                userID = currentUser.getUid();
            } else {
                Toast.makeText(this, "Error: User not logged in.", Toast.LENGTH_LONG).show();
                finish(); // Close the activity if there's no user ID
                return;
            }
        }

        // Initialize Views
        initializeViews();

        // Submit Button OnClickListener
        Button submitButton = findViewById(R.id.submitbutton);
        submitButton.setOnClickListener(v -> {
            if (validateInput()) {
                sendToFirebase();
            }
        });

        // Back Button OnClickListener
        ImageButton backButton = findViewById(R.id.imageButton4);
        backButton.setOnClickListener(v -> finish());
    }

    private void initializeViews() {
        firstNameEditText = findViewById(R.id.firstNameEditText);
        lastNameEditText = findViewById(R.id.lastNameEditText);
        schoolIdEditText = findViewById(R.id.schoolIdEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        universityEditText = findViewById(R.id.universityEditText);
        degreeTypeSpinner = findViewById(R.id.degreeTypeSpinner);
        degreeAwardedEditText = findViewById(R.id.degreeAwardedEditText);
        yearAchievedEditText = findViewById(R.id.yearAchivedEditText);

        // Initialize Spinner with degree types
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"Select a Degree type", "Bachelor's Science", "Associates Science", "Associates Arts",
                        "Bachelor's Arts", "Master's Science", "Master's Arts", "PhD", "DR"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        degreeTypeSpinner.setAdapter(adapter);
        degreeTypeSpinner.setSelection(0);
    }

    private boolean validateInput() {
        // Check if any of the input fields are empty and validate birthdate format
        if (isEmpty(firstNameEditText, "First Name is required") ||
                isEmpty(lastNameEditText, "Last Name is required") ||
                isEmpty(birthdateEditText, "Birthdate is required") ||
                isEmpty(schoolIdEditText, "School ID is required") ||
                isEmpty(universityEditText, "University is required") ||
                isEmpty(degreeAwardedEditText, "Degree Awarded is required") ||
                isEmpty(yearAchievedEditText, "Year Achieved is required") ||
                degreeTypeSpinner.getSelectedItemPosition() <= 0) {
            return false;
        }

        // Validate birthdate format
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(birthdateEditText.getText().toString());
        } catch (ParseException e) {
            showToast("Birthdate must be in MM/DD/YYYY format");
            return false;
        }
        return true;
    }

    private boolean isEmpty(EditText editText, String errorMessage) {
        if (editText.getText().toString().trim().isEmpty()) {
            showToast(errorMessage);
            editText.requestFocus();
            return true;
        }
        return false;
    }

    private void sendToFirebase() {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("DegreeValidation");

        HashMap<String, Object> dataMap = new HashMap<>();
        dataMap.put("firstName", firstNameEditText.getText().toString());
        dataMap.put("lastName", lastNameEditText.getText().toString());
        dataMap.put("birthdate", birthdateEditText.getText().toString());
        dataMap.put("schoolId", schoolIdEditText.getText().toString());
        dataMap.put("university", universityEditText.getText().toString());
        dataMap.put("degreeType", degreeTypeSpinner.getSelectedItem().toString());
        dataMap.put("degreeAwarded", degreeAwardedEditText.getText().toString());
        dataMap.put("yearAchieved", yearAchievedEditText.getText().toString());

        // Use the userID as the key for the database entry
        databaseReference.child(userID).setValue(dataMap)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(validatedegree.this, "Data successfully linked to your User ID", Toast.LENGTH_SHORT).show();
                    // Navigate back to MainActivity or another activity after successful data submission
                    Intent intent = new Intent(validatedegree.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Finish this activity
                })
                .addOnFailureListener(e -> {
                    // Handle the error, provide feedback
                    Toast.makeText(validatedegree.this, "Failed to save data. Please try again.", Toast.LENGTH_SHORT).show();
                });
    }



    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}
